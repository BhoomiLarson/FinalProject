-- create and use new database
DROP DATABASE IF EXISTS FruitVendor;
GO

CREATE DATABASE FruitVendor;
GO

USE FruitVendor
GO

-- create tables
CREATE TABLE Categories
	(CategoryID int PRIMARY KEY IDENTITY,
	 CategoryName varchar(50) NOT NULL UNIQUE);

CREATE TABLE Products
	(ProductID int PRIMARY KEY IDENTITY,
	 CategoryID int NOT NULL REFERENCES Categories (CategoryID),
	 ProductName varchar(50) NOT NULL UNIQUE,
	 ListPrice money NOT NULL,
	 -- negative check constraint for QuantityLeft
	 QuantityLeft int NOT NULL DEFAULT 0 CHECK (QuantityLeft >= 0), 
	 DateAdded datetime2(7) NOT NULL DEFAULT (SYSDATETIME()));

CREATE TABLE Customers
	(CustomerID int PRIMARY KEY IDENTITY,
	 EmailAddress varchar(250) NOT NULL UNIQUE,
	 FirstName varchar(250) NOT NULL,
	 LastName varchar(250) NOT NULL);

CREATE TABLE Orders
	(OrderID int PRIMARY KEY IDENTITY,
	 CustomerID int NOT NULL REFERENCES Customers (CustomerID),
	 OrderDate datetime2(7) NOT NULL DEFAULT (SYSDATETIME()));

CREATE TABLE OrderItems
	(ItemID int PRIMARY KEY IDENTITY,
	 OrderID int NOT NULL REFERENCES Orders (OrderID),
	 ProductID int NOT NULL REFERENCES Products (ProductID),
	 ItemPrice money NOT NULL,
	 -- negative check constraint for QuantityBought
	 QuantityBought int NOT NULL DEFAULT 0 CHECK (QuantityBought >= 0));
GO

-- create indexes
CREATE INDEX IX_CategoryName
	ON Categories (CategoryName);

CREATE INDEX IX_ProductName
	ON Products (ProductName);

CREATE INDEX IX_EmailAddress
	ON Customers (EmailAddress);

CREATE INDEX IX_FirstName
	ON Customers (FirstName);

CREATE INDEX IX_LastName
	ON Customers (LastName);
GO

-- add all table entries
INSERT INTO Categories
	(CategoryName)
VALUES
	('Fruit'),
	('Vegetable');

INSERT INTO Products
	(CategoryID, ProductName, ListPrice, QuantityLeft, DateAdded)
VALUES
	(1, 'Apple', 3.00, 10, GETDATE()),
	(1, 'Banana', 5.00, 10, GETDATE()),
	(1, 'Orange', 5.00, 10, GETDATE()),
	(2, 'Potato', 3.00, 10, GETDATE()),
	(2, 'Onion', 7.00, 10, GETDATE());

INSERT INTO Customers
	(EmailAddress, FirstName, LastName)
VALUES
	('JaneDoe@gmail.com', 'Jane', 'Doe'),
	('JSmith@gmail.com', 'John', 'Smith'),
	('JohnDoe@yahoo.com', 'John', 'Doe'),
	('FooleryTom@yahoo.com', 'Tom', 'Foolery'),
	('RRoe@gmail.com', 'Richard', 'Roe');

INSERT INTO Orders 
	(CustomerID, OrderDate)
VALUES
	(1, GETDATE()),
	(1, GETDATE()),
	(2, GETDATE()),
	(3, GETDATE()),
	(3, GETDATE()),
	(4, GETDATE()),
	(5, GETDATE());

INSERT INTO OrderItems
	(OrderID, ProductID, ItemPrice, QuantityBought)
VALUES
	(1, 1, 3.00, 3), -- 1 respective CustomerID from Orders
	(2, 3, 5.00, 2), -- 1
	(3, 2, 5.00, 1), -- 2
	(4, 1, 3.00, 1), -- 3
	(5, 5, 7.00, 2), -- 3
	(6, 4, 3.00, 4), -- 4
	(7, 4, 3.00, 4); -- 5
GO

-- create view to generate receipts
DROP VIEW IF EXISTS Receipt;
GO

CREATE VIEW Receipt
AS
SELECT c.CustomerID, EmailAddress, FirstName, LastName,
	ProductName, ListPrice, ItemPrice, oi.QuantityBought,
	SUM(ItemPrice * oi.QuantityBought) AS TotalPrice
FROM Customers c
	JOIN Orders o
		ON c.CustomerID = o.CustomerID
	JOIN OrderItems oi
		ON o.OrderID = oi.OrderID
	JOIN Products p
		ON oi.ProductID = p.ProductID
GROUP BY c.CustomerID, EmailAddress, FirstName, LastName, 
	ProductName, ListPrice, ItemPrice, oi.QuantityBought;
GO

-- select all purchases
SELECT * 
FROM Receipt;

-- select all purchases for CustomerID 1
SELECT * 
FROM Receipt
WHERE CustomerID = 1;
GO

-- stored procedure that shows a products details
DROP PROCEDURE IF EXISTS spProductDetails;
GO

CREATE PROCEDURE spProductDetails
	-- determine parameters
	@ProductID int,
	@ProductName varchar(50) = NULL OUTPUT,
	@ListPrice money = NULL OUTPUT,
	@QuantityLeft int = NULL OUTPUT
AS
BEGIN
	-- get parameter values from Products table
	SELECT @ProductName = ProductName,
		   @ListPrice = ListPrice,
		   @QuantityLeft = QuantityLeft
	FROM Products
	WHERE ProductID = @ProductID

	-- show procedure output
	PRINT 'ProductID: ' + CAST(@ProductID AS varchar(10));
	PRINT 'ProductName: ' + CAST(@ProductName AS varchar(50));
	PRINT 'ListPrice: ' + CAST(@ListPrice AS varchar(50));
	PRINT 'QuantityLeft: ' + CAST(@QuantityLeft AS varchar(50));
END;
GO

-- execute procedure for ProductID 3
EXEC spProductDetails 3;
GO

-- last name capitalization trigger
CREATE TRIGGER CapitalLastName
ON Customers
FOR INSERT, UPDATE
AS
UPDATE Customers
SET LastName = UPPER(LastName);
GO

-- add customer to Customers table to test trigger
INSERT INTO Customers
	(EmailAddress, FirstName, LastName)
VALUES 
	('JaneSmith@yahoo.com', 'Jane', 'smith');
GO

-- check to see trigger result
SELECT * FROM Customers
GO

-- transaction for buying an item
-- NOTE: OrderID in OrderItems table is unable to update due to FK constraint
BEGIN TRAN;

-- declare variables
DECLARE @ProductID int = 2;
DECLARE @QuantityBought int = 2;
DECLARE @ListPrice money = 5.00
DECLARE @QuantityLeft int = 10;

-- get QuantityLeft from Products table
SELECT @QuantityLeft = QuantityLeft
FROM Products
WHERE ProductID = @ProductID;

-- roll back transaction conditions
IF @QuantityLeft = 0
	BEGIN
		PRINT 'Item out of stock. Transaction rolled back.';
		ROLLBACK TRAN;
	END
ELSE IF @QuantityLeft < @QuantityBought
	BEGIN
		PRINT 'Bought amount larger than current stock. Transaction rolled back.';
		ROLLBACK TRAN;
	END
-- commit transaction condition
ELSE
	BEGIN
		INSERT INTO OrderItems 
			(ProductID, ItemPrice, QuantityBought)
		VALUES
			(@ProductID, @ListPrice, @QuantityBought)

		UPDATE Products
		SET QuantityLeft = QuantityLeft - @QuantityBought
		WHERE ProductID = @ProductID;

		COMMIT TRAN;
		PRINT 'Transaction successful.';
	END
GO

-- create users and grant database access
-- NOTE: object explorer tab was used for admin user creation and access
-- create staff user and role
CREATE ROLE ProductEntry;

GRANT INSERT, UPDATE
ON Products
TO ProductEntry;

ALTER ROLE db_datareader ADD MEMBER ProductEntry;

CREATE LOGIN RobertHalliday WITH PASSWORD = 'HelloBob!',
	DEFAULT_DATABASE = FruitVendor;

CREATE USER RobertHalliday FOR LOGIN RobertHalliday;

ALTER ROLE ProductEntry ADD MEMBER RobertHalliday;
